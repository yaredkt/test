package UI;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LogIn extends Application {
	
	public static void main (String[] args) {
		
		launch(args);
	}
	
	GridPane grid1 = null;
	Text messageBar = new Text();
	
	Stage bankAccount;
	Stage primaryStage;
	
	private void createSecondWindwo() {
		
		bankAccount = new BankAccount(primaryStage);
		messageBar.setText("");
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		this.primaryStage = primaryStage;
		primaryStage.setTitle("Two Windows");
		createSecondWindwo();
		
		
		primaryStage.setTitle("LOGIN");
		
		GridPane grid = new GridPane();
		
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setStyle("-fx-background: #6495ED;");

		
		
		
		grid.setPadding(new Insets(50, 50, 50, 50));
		
		Text title = new Text("Bank of America");
		title.setFill(Color.WHITE);
		title.setFont(Font.font("Times New Roman", FontWeight.BOLD, 20));
		grid.add(title, 0, 1, 2, 1);
		
		Label userId = new Label("User Name");
		userId.setTextFill(Color.WHITE);
		userId.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		grid.add(userId, 0, 4);
		
		TextField userIdTextField = new TextField("User Name");
		grid.add(userIdTextField, 1, 4);
		
		Label password = new Label("Password");
		password.setTextFill(Color.WHITE);
		password.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		grid.add(password, 0, 5);
		
		PasswordField passwordField = new PasswordField();
		passwordField.setPromptText("password");
		grid.add(passwordField ,1, 5);
		
		Button signin = new Button("Sing in");
		signin.setTextFill(Color.BLACK);
		signin.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		HBox hbsign = new HBox(8);
		hbsign.setAlignment(Pos.BOTTOM_CENTER);
		hbsign.getChildren().add(signin);
		grid.add(hbsign, 1,8);
		
		
		class MessageBarHandler implements EventHandler<ActionEvent> {
			@Override public void handle(ActionEvent e) {
				messageBar.setText("");
		        bankAccount.show();  
		    }
		}
		//action  event
		signin.setOnAction(new MessageBarHandler());
		
		
	   
		
		Scene scene = new Scene(grid, 400, 300);
		
//		Image image = new Image("file:image2.jpg");
//		ImageView iv = new ImageView();
//		iv.setImage(image);
//		
//		//iv.setFitWidth(400);
//		//iv.setFitHeight(300);
//		iv.autosize();
//		grid.getChildren().add(iv);
		
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

}
