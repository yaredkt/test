package UI;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class BankAccount extends Stage {
	
	private static final Color DEFAULT_COLOR = Color.CORNFLOWERBLUE;

	Stage primaryStage;

	@SuppressWarnings("serial")

	GridPane grid = new GridPane();

	public BankAccount(Stage bc) {

		primaryStage = bc;
		setTitle("Bank Account");
		
		grid.setAlignment(Pos.TOP_LEFT);
		grid.setHgap(10);
		grid.setVgap(10);
		
		
		Label userId = new Label("User Name");
		userId.setTextFill(Color.BLACK);
		userId.setFont(Font.font("Times New Roman", FontWeight.LIGHT, 16));
		grid.add(userId, 0, 4);
		
		TextField userIdTextField = new TextField();
		grid.add(userIdTextField, 1, 4);
		

		Scene scene = new Scene(grid, 800, 500);
		positionSceneInStage(this, scene);
        setBackground(DEFAULT_COLOR);
        scene.setFill(Color.BEIGE);
		setScene(scene);
		
	}
	
	void setBackground(Color color) {
		grid.backgroundProperty().set(new Background(new BackgroundFill(color, CornerRadii.EMPTY, Insets.EMPTY)));
	}
	
	void positionSceneInStage(Stage stage, Scene scene) { 
		stage.setX(600); 
		stage.setY(200); 
	}
	

}
